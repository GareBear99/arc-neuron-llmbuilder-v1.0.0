
import time

class WorkerEngine:

    def __init__(self, queue, pipeline):
        self.queue = queue
        self.pipeline = pipeline

    def run(self):
        while True:
            if not self.queue:
                time.sleep(1)
                continue

            item = self.queue.pop(0)
            try:
                self.pipeline.run(item)
            except Exception as e:
                print("Worker error:", e)
