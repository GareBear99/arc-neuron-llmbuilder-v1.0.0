
from fastapi import APIRouter

router = APIRouter()

SIGNALS = {}

@router.get("/signals/{entity}")
def entity_signal(entity):
    return SIGNALS.get(entity, [])
