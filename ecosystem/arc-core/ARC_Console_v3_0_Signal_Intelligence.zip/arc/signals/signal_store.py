
from collections import defaultdict
import time

class SignalStore:

    def __init__(self):
        self.entity_signals = defaultdict(list)
        self.relationship_signals = defaultdict(list)

    def add_entity_signal(self, entity):
        ts = int(time.time())
        self.entity_signals[entity].append(ts)

    def add_relationship_signal(self, a, b):
        ts = int(time.time())
        key = f"{a}->{b}"
        self.relationship_signals[key].append(ts)

    def get_entity_series(self, entity):
        return self.entity_signals.get(entity, [])
