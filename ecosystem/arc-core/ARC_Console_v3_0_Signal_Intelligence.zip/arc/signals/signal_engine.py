
class SignalEngine:

    def __init__(self, store):
        self.store = store

    def process_entities(self, entities):
        for e in entities:
            self.store.add_entity_signal(e)

    def process_relationships(self, pairs):
        for a,b in pairs:
            self.store.add_relationship_signal(a,b)
