
class InfluenceEngine:

    def __init__(self):
        self.source_weights = {}

    def set_weight(self, source, weight):
        self.source_weights[source] = weight

    def weight(self, source):
        return self.source_weights.get(source,1)
