
import time

class TrendDetector:

    def detect_spike(self, series, window=3600):
        now = int(time.time())
        recent = [t for t in series if now - t < window]

        if len(recent) > 10:
            return True
        return False
