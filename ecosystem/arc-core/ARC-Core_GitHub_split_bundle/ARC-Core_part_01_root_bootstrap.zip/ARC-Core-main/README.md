# ARC-Core

ARC-Core is a deterministic operator-grade intelligence scaffold inspired by the surveillance-analysis feel of ARC in *Continuum*.

This package is **not** fictional omniscience. It is a grounded engineering interpretation of the pattern:

**ingest → resolve → correlate → score → watch → case → propose → approve → simulate → geolocate → export evidence → verify receipts → authenticate → connect → poll → annotate**

## What this v6 build includes

- FastAPI runtime with operator API and static console
- SQLite-backed persistent event/state store
- canonical event envelope and replayable history
- entity resolution and relationship graph snapshots
- watchlists, cases, proposals, approvals, and branch simulation
- geospatial structure registry and seeded indoor sensor deployment
- weighted RSSI-style geotracking estimates with candidate cloud output
- geofence monitoring and track history persistence
- structure heatmap generation from stored tracks
- blueprint overlay metadata for floorplan alignment
- calibration profile storage for per-structure tuning
- imported track ingestion for JSON-style paths
- incident workflow records
- enriched evidence pack export for cases or tracked subjects
- tamper-evident **signed** receipt chain with verification endpoint
- local auth bootstrap, session issuance, and bearer-session aware role gates
- connector bus with filesystem JSONL adapter and run history
- analyst notebook / note capture bound to cases, entities, subjects, or connectors
- cleaned packaging with no bundled runtime clutter
- extended test suite covering auth, connectors, notes, receipts, geo, evidence, search, dedupe, and idempotent upserts

## Architecture

- `arc/api/` - HTTP routes and app entrypoint
- `arc/core/` - config, database, schemas, auth, risk, simulation
- `arc/services/` - ingest, resolve, graph, cases, proposals, audit, geospatial, authn, connectors, notebook
- `arc/geo/` - geometry and estimator primitives
- `arc/ui/` - static operator console
- `data/` - runtime SQLite database, connector inboxes, signing key
- `tests/` - smoke and workflow validation suite

## Quick start

```bash
cd ARC_Console
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python seed_demo.py
uvicorn run_arc:app --reload
```

Open:
- `/`
- `/ui/signals.html`
- `/ui/graph.html`
- `/ui/timeline.html`
- `/ui/cases.html`
- `/ui/geo.html`

## Roles

Header-based role gating is still supported through `X-ARC-Role`:

- `observer`
- `analyst`
- `operator`
- `approver`
- `admin`

You can now also issue a bearer session:

```bash
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"arc-demo-admin","source":"cli"}'
```

Then use the returned token:

```bash
curl http://127.0.0.1:8000/api/connectors \
  -H 'Authorization: Bearer <token>'
```

Optional hardening:
- set `ARC_SHARED_TOKEN` in the environment
- send the same value as `X-ARC-Token` for non-session write paths
- set `ARC_BOOTSTRAP_PASSWORD` to rotate the default bootstrap password

## Connector bus

The included connector bus is **local and deterministic**, not covert collection.

Current adapter:
- `filesystem_jsonl`

Drop JSONL files into a connector inbox and poll the connector. Each line should be an event-like JSON object, for example:

```json
{"event_type":"presence","source":"filesystem-demo","subject":"Demo Device","location":"Pine House","confidence":0.81,"severity":4}
```

## Main API surfaces

- `/api/manifest`
- `/api/auth/bootstrap`
- `/api/auth/login`
- `/api/auth/session`
- `/api/connectors`
- `/api/connectors/{connector_id}/poll`
- `/api/notes`
- `/api/evidence`
- `/api/receipts`
- `/api/receipts/verify`
- `/api/incidents`
- `/api/geo/heatmap/{structure_id}`
- `/api/geo/blueprints`
- `/api/geo/calibrations`
- `/api/geo/import-tracks`

## What still is not fictional-show complete

- no real external/live collection adapters beyond the local filesystem connector
- no hardware-backed signing or asymmetric key management
- identity fusion is still deterministic and label-centric, not probabilistic multi-source resolution
- no distributed stream processing, queues, or backpressure orchestration
- no polished multi-user UI for sessions and notebook workflows
- RF/geospatial model remains simulated indoor estimation, not validated physical telemetry

This build is now a more disciplined **credible ARC-style kernel + spatial operator console + local connector/auth layer**, but it remains a local deterministic intelligence prototype rather than a magical surveillance system.
